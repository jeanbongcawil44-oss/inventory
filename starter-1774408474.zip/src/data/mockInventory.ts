import { InventoryItem, ItemStatus } from "@/types/inventory";

const LOW_STOCK_THRESHOLD = 10;

export function computeStatus(quantity: number): ItemStatus {
  if (quantity === 0) return "out-of-stock";
  if (quantity <= LOW_STOCK_THRESHOLD) return "low";
  return "in-stock";
}

export const MOCK_ITEMS: InventoryItem[] = [
  {
    id: "1",
    name: "Wireless Keyboard",
    sku: "WK-1001",
    category: "Electronics",
    quantity: 45,
    unitPrice: 89.99,
    supplier: "TechSupply Co.",
    status: "in-stock",
  },
  {
    id: "2",
    name: "USB-C Hub",
    sku: "UC-2045",
    category: "Electronics",
    quantity: 7,
    unitPrice: 49.99,
    supplier: "TechSupply Co.",
    status: "low",
  },
  {
    id: "3",
    name: "Ergonomic Mouse",
    sku: "EM-3012",
    category: "Electronics",
    quantity: 0,
    unitPrice: 65.0,
    supplier: "PeripheralsPro",
    status: "out-of-stock",
  },
  {
    id: "4",
    name: "Standing Desk Mat",
    sku: "SDM-4001",
    category: "Furniture",
    quantity: 22,
    unitPrice: 34.5,
    supplier: "ErgoWorks",
    status: "in-stock",
  },
  {
    id: "5",
    name: "Monitor Stand",
    sku: "MS-5078",
    category: "Furniture",
    quantity: 3,
    unitPrice: 120.0,
    supplier: "ErgoWorks",
    status: "low",
  },
  {
    id: "6",
    name: "Notebook A5",
    sku: "NB-6021",
    category: "Stationery",
    quantity: 150,
    unitPrice: 8.99,
    supplier: "OfficeEssentials",
    status: "in-stock",
  },
  {
    id: "7",
    name: "Whiteboard Markers",
    sku: "WM-7005",
    category: "Stationery",
    quantity: 5,
    unitPrice: 12.5,
    supplier: "OfficeEssentials",
    status: "low",
  },
  {
    id: "8",
    name: "Webcam HD 1080p",
    sku: "WC-8034",
    category: "Electronics",
    quantity: 18,
    unitPrice: 95.0,
    supplier: "TechSupply Co.",
    status: "in-stock",
  },
  {
    id: "9",
    name: "Cable Management Box",
    sku: "CM-9002",
    category: "Accessories",
    quantity: 30,
    unitPrice: 22.0,
    supplier: "NeatDesk",
    status: "in-stock",
  },
  {
    id: "10",
    name: "Desk Lamp LED",
    sku: "DL-1102",
    category: "Furniture",
    quantity: 0,
    unitPrice: 55.0,
    supplier: "LightCraft",
    status: "out-of-stock",
  },
  {
    id: "11",
    name: "Thermal Label Printer",
    sku: "TL-1203",
    category: "Electronics",
    quantity: 9,
    unitPrice: 299.0,
    supplier: "PrintMaster",
    status: "low",
  },
  {
    id: "12",
    name: "Bubble Wrap Roll",
    sku: "BW-1304",
    category: "Packaging",
    quantity: 60,
    unitPrice: 18.75,
    supplier: "PackRight",
    status: "in-stock",
  },
];

export const LOW_STOCK_THRESHOLD_VALUE = LOW_STOCK_THRESHOLD;
