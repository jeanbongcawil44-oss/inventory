import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Eye, EyeOff, Package, Lock, Mail, AlertCircle, User } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { DEMO_ACCOUNTS } from "@/types/auth";

const FIELD_STYLE =
  "w-full px-4 py-3 text-sm bg-[#0F1117] border border-[#2A2D3A] rounded-xl text-[#E8EAF0] placeholder-[#7B8099] focus:outline-none focus:border-[#00C9A7]/70 focus:ring-2 focus:ring-[#00C9A7]/20 transition-all";

type Tab = "login" | "register";

export default function LoginPage() {
  const { login, register } = useAuth();
  const [tab, setTab] = useState<Tab>("login");

  // Login state
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginShowPass, setLoginShowPass] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);

  // Register state
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regConfirm, setRegConfirm] = useState("");
  const [regShowPass, setRegShowPass] = useState(false);
  const [regError, setRegError] = useState("");
  const [regLoading, setRegLoading] = useState(false);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError("");
    setLoginLoading(true);
    await new Promise((r) => setTimeout(r, 600));
    const result = login(loginEmail, loginPassword);
    if (!result.success) {
      setLoginError(result.error || "Login failed");
    }
    setLoginLoading(false);
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setRegError("");
    if (regPassword !== regConfirm) {
      setRegError("Passwords do not match");
      return;
    }
    setRegLoading(true);
    await new Promise((r) => setTimeout(r, 700));
    const result = register(regName, regEmail, regPassword);
    if (!result.success) {
      setRegError(result.error || "Registration failed");
    }
    setRegLoading(false);
  };

  const fillDemo = (acc: (typeof DEMO_ACCOUNTS)[number]) => {
    setLoginEmail(acc.email);
    setLoginPassword(acc.password);
    setLoginError("");
    if (tab !== "login") setTab("login");
  };

  return (
    <div
      className="min-h-screen flex items-center justify-center px-4"
      style={{
        background: "#0F1117",
        fontFamily: "Space Grotesk, sans-serif",
        backgroundImage:
          "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E\")",
      }}
    >
      {/* Ambient glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 40% at 50% 0%, rgba(0,201,167,0.07) 0%, transparent 70%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
        className="w-full max-w-md relative"
      >
        {/* Card */}
        <div
          className="rounded-2xl border border-[#2A2D3A] p-8"
          style={{ background: "#1A1D27" }}
        >
          {/* Logo */}
          <div className="flex items-center gap-3 mb-8">
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center"
              style={{ background: "#00C9A7" }}
            >
              <Package className="w-5 h-5 text-[#0F1117]" />
            </div>
            <div>
              <h1
                className="text-xl font-bold text-[#E8EAF0]"
                style={{ fontFamily: "Syne, sans-serif" }}
              >
                StockPilot
              </h1>
              <p className="text-xs text-[#7B8099]">Inventory Management</p>
            </div>
          </div>

          {/* Tabs */}
          <div className="flex rounded-xl border border-[#2A2D3A] p-1 mb-6 bg-[#0F1117]">
            {(["login", "register"] as Tab[]).map((t) => (
              <button
                key={t}
                onClick={() => setTab(t)}
                className="flex-1 py-2 rounded-lg text-sm font-semibold transition-all capitalize"
                style={{
                  background: tab === t ? "#00C9A7" : "transparent",
                  color: tab === t ? "#0F1117" : "#7B8099",
                }}
              >
                {t === "login" ? "Sign In" : "Register"}
              </button>
            ))}
          </div>

          <AnimatePresence mode="wait">
            {tab === "login" ? (
              <motion.form
                key="login"
                initial={{ opacity: 0, x: -12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 12 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleLogin}
                className="space-y-4"
              >
                <div>
                  <p className="text-2xl font-bold text-[#E8EAF0] mb-1" style={{ fontFamily: "Syne, sans-serif" }}>
                    Welcome back
                  </p>
                  <p className="text-sm text-[#7B8099] mb-5">Sign in to your dashboard</p>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B8099]" />
                    <input
                      type="email"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      placeholder="you@company.com"
                      className={`${FIELD_STYLE} pl-10`}
                      required
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B8099]" />
                    <input
                      type={loginShowPass ? "text" : "password"}
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      placeholder="••••••••"
                      className={`${FIELD_STYLE} pl-10 pr-10`}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setLoginShowPass((v) => !v)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#7B8099] hover:text-[#E8EAF0] transition-colors"
                    >
                      {loginShowPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {loginError && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[#E05C5C]/10 border border-[#E05C5C]/30 text-[#E05C5C] text-sm"
                  >
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    {loginError}
                  </motion.div>
                )}

                <button
                  type="submit"
                  disabled={loginLoading}
                  className="w-full py-3 rounded-xl text-sm font-bold text-[#0F1117] transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60 mt-2"
                  style={{ background: "#00C9A7" }}
                >
                  {loginLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeDasharray="40" strokeDashoffset="10" />
                      </svg>
                      Signing in...
                    </span>
                  ) : (
                    "Sign In"
                  )}
                </button>
              </motion.form>
            ) : (
              <motion.form
                key="register"
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -12 }}
                transition={{ duration: 0.2 }}
                onSubmit={handleRegister}
                className="space-y-4"
              >
                <div>
                  <p className="text-2xl font-bold text-[#E8EAF0] mb-1" style={{ fontFamily: "Syne, sans-serif" }}>
                    Create account
                  </p>
                  <p className="text-sm text-[#7B8099] mb-5">Register to access your dashboard</p>
                </div>

                {/* Name */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Full Name
                  </label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B8099]" />
                    <input
                      type="text"
                      value={regName}
                      onChange={(e) => setRegName(e.target.value)}
                      placeholder="Your full name"
                      className={`${FIELD_STYLE} pl-10`}
                      required
                    />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B8099]" />
                    <input
                      type="email"
                      value={regEmail}
                      onChange={(e) => setRegEmail(e.target.value)}
                      placeholder="you@company.com"
                      className={`${FIELD_STYLE} pl-10`}
                      required
                    />
                  </div>
                </div>

                {/* Password */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B8099]" />
                    <input
                      type={regShowPass ? "text" : "password"}
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      placeholder="Min. 6 characters"
                      className={`${FIELD_STYLE} pl-10 pr-10`}
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setRegShowPass((v) => !v)}
                      className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#7B8099] hover:text-[#E8EAF0] transition-colors"
                    >
                      {regShowPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Confirm Password */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Confirm Password
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B8099]" />
                    <input
                      type={regShowPass ? "text" : "password"}
                      value={regConfirm}
                      onChange={(e) => setRegConfirm(e.target.value)}
                      placeholder="Repeat password"
                      className={`${FIELD_STYLE} pl-10`}
                      required
                    />
                  </div>
                </div>

                {regError && (
                  <motion.div
                    initial={{ opacity: 0, y: -4 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="flex items-center gap-2 px-3 py-2.5 rounded-lg bg-[#E05C5C]/10 border border-[#E05C5C]/30 text-[#E05C5C] text-sm"
                  >
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    {regError}
                  </motion.div>
                )}

                <button
                  type="submit"
                  disabled={regLoading}
                  className="w-full py-3 rounded-xl text-sm font-bold text-[#0F1117] transition-all hover:opacity-90 active:scale-[0.98] disabled:opacity-60 mt-2"
                  style={{ background: "#00C9A7" }}
                >
                  {regLoading ? (
                    <span className="flex items-center justify-center gap-2">
                      <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24" fill="none">
                        <circle cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" strokeDasharray="40" strokeDashoffset="10" />
                      </svg>
                      Creating account...
                    </span>
                  ) : (
                    "Create Account"
                  )}
                </button>
              </motion.form>
            )}
          </AnimatePresence>
        </div>

        {/* Demo accounts - only show on login tab */}
        {tab === "login" && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="mt-5"
          >
            <p className="text-xs text-[#7B8099] text-center mb-3">
              Quick access — demo accounts
            </p>
            <div className="grid grid-cols-3 gap-2">
              {DEMO_ACCOUNTS.map((acc) => (
                <button
                  key={acc.id}
                  onClick={() => fillDemo(acc)}
                  className="px-3 py-2.5 rounded-xl border border-[#2A2D3A] text-center transition-all hover:border-[#00C9A7]/40 hover:bg-[#00C9A7]/5 group"
                >
                  <div
                    className="w-7 h-7 rounded-lg mx-auto mb-1 flex items-center justify-center text-xs font-bold text-[#0F1117]"
                    style={{ background: "#00C9A7" }}
                  >
                    {acc.avatar}
                  </div>
                  <p className="text-xs font-semibold text-[#E8EAF0] capitalize">
                    {acc.role}
                  </p>
                  <p className="text-[10px] text-[#7B8099] mt-0.5 truncate">{acc.password}</p>
                </button>
              ))}
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}

