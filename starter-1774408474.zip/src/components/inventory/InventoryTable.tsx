import { ChevronDown, ChevronUp, ChevronsUpDown, Pencil, Trash2 } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { InventoryItem, SortConfig, SortField } from "@/types/inventory";

interface InventoryTableProps {
  items: InventoryItem[];
  sortConfig: SortConfig;
  onSort: (field: SortField) => void;
  onEdit: (item: InventoryItem) => void;
  onDelete: (id: string) => void;
  deletingId: string | null;
}

const STATUS_CONFIG = {
  "in-stock": { label: "In Stock", bg: "#00C9A7/15", text: "#00C9A7", dot: "#00C9A7" },
  low: { label: "Low Stock", bg: "#F5A623/15", text: "#F5A623", dot: "#F5A623" },
  "out-of-stock": { label: "Out of Stock", bg: "#E05C5C/15", text: "#E05C5C", dot: "#E05C5C" },
};

const COLUMNS: { label: string; field: SortField | null; width?: string }[] = [
  { label: "Item Name", field: "name", width: "w-[22%]" },
  { label: "SKU", field: "sku", width: "w-[10%]" },
  { label: "Category", field: "category", width: "w-[12%]" },
  { label: "Quantity", field: "quantity", width: "w-[10%]" },
  { label: "Unit Price", field: "unitPrice", width: "w-[11%]" },
  { label: "Status", field: "status", width: "w-[14%]" },
  { label: "Actions", field: null, width: "w-[10%]" },
];

function SortIcon({ field, sortConfig }: { field: SortField; sortConfig: SortConfig }) {
  if (sortConfig.field !== field) return <ChevronsUpDown className="w-3.5 h-3.5 opacity-30" />;
  return sortConfig.direction === "asc" ? (
    <ChevronUp className="w-3.5 h-3.5 text-[#00C9A7]" />
  ) : (
    <ChevronDown className="w-3.5 h-3.5 text-[#00C9A7]" />
  );
}

export default function InventoryTable({
  items,
  sortConfig,
  onSort,
  onEdit,
  onDelete,
  deletingId,
}: InventoryTableProps) {
  return (
    <div className="rounded-xl border border-[#2A2D3A] overflow-hidden" style={{ background: "#1A1D27" }}>
      {/* Header */}
      <div
        className="grid items-center px-5 py-3 border-b border-[#2A2D3A] text-xs font-semibold text-[#7B8099] uppercase tracking-wider"
        style={{
          gridTemplateColumns: "2.2fr 1fr 1.2fr 1fr 1.1fr 1.4fr 1fr",
          fontFamily: "Space Grotesk, sans-serif",
        }}
      >
        {COLUMNS.map((col) => (
          <div key={col.label} className="flex items-center gap-1">
            {col.field ? (
              <button
                onClick={() => onSort(col.field!)}
                className="flex items-center gap-1 hover:text-[#E8EAF0] transition-colors"
              >
                {col.label}
                <SortIcon field={col.field} sortConfig={sortConfig} />
              </button>
            ) : (
              <span>{col.label}</span>
            )}
          </div>
        ))}
      </div>

      {/* Body */}
      <div className="divide-y divide-[#2A2D3A]/60">
        <AnimatePresence mode="popLayout" initial={false}>
          {items.map((item, idx) => {
            const status = STATUS_CONFIG[item.status];
            const isDeleting = deletingId === item.id;
            const isLowOrOut = item.status === "low" || item.status === "out-of-stock";

            return (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: -8 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0, marginTop: 0, paddingTop: 0, paddingBottom: 0 }}
                transition={{ duration: 0.25, delay: idx * 0.04, layout: { duration: 0.2 } }}
                className={`grid items-center px-5 py-4 transition-colors group ${
                  isDeleting ? "opacity-40" : ""
                } ${
                  isLowOrOut
                    ? "bg-[#F5A623]/[0.02] hover:bg-[#F5A623]/[0.05]"
                    : "hover:bg-[#ffffff]/[0.02]"
                }`}
                style={{
                  gridTemplateColumns: "2.2fr 1fr 1.2fr 1fr 1.1fr 1.4fr 1fr",
                  fontFamily: "Space Grotesk, sans-serif",
                }}
              >
                {/* Name */}
                <div className="flex items-center gap-3 min-w-0">
                  {isLowOrOut && (
                    <div
                      className="w-1.5 h-8 rounded-full shrink-0"
                      style={{ background: item.status === "out-of-stock" ? "#E05C5C" : "#F5A623" }}
                    />
                  )}
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-[#E8EAF0] truncate">{item.name}</div>
                    <div className="text-xs text-[#7B8099]">{item.supplier}</div>
                  </div>
                </div>

                {/* SKU */}
                <div className="text-sm text-[#7B8099] font-mono">{item.sku}</div>

                {/* Category */}
                <div>
                  <span className="inline-flex px-2.5 py-0.5 rounded-md text-xs font-medium bg-[#ffffff]/5 text-[#7B8099] border border-[#2A2D3A]">
                    {item.category}
                  </span>
                </div>

                {/* Quantity */}
                <div
                  className="text-sm font-semibold tabular-nums"
                  style={{
                    color:
                      item.status === "out-of-stock"
                        ? "#E05C5C"
                        : item.status === "low"
                        ? "#F5A623"
                        : "#E8EAF0",
                  }}
                >
                  {item.quantity}
                  <span className="text-xs text-[#7B8099] font-normal ml-1">units</span>
                </div>

                {/* Price */}
                <div className="text-sm text-[#E8EAF0] tabular-nums font-medium">
                  ${item.unitPrice.toFixed(2)}
                </div>

                {/* Status */}
                <div>
                  <span
                    className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-xs font-medium"
                    style={{
                      background: `${status.dot}18`,
                      color: status.text,
                      border: `1px solid ${status.dot}30`,
                    }}
                  >
                    <span
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ background: status.dot }}
                    />
                    {status.label}
                  </span>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => onEdit(item)}
                    className="p-1.5 rounded-lg text-[#7B8099] hover:text-[#00C9A7] hover:bg-[#00C9A7]/10 transition-all opacity-0 group-hover:opacity-100"
                    title="Edit item"
                  >
                    <Pencil className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDelete(item.id)}
                    className="p-1.5 rounded-lg text-[#7B8099] hover:text-[#E05C5C] hover:bg-[#E05C5C]/10 transition-all opacity-0 group-hover:opacity-100"
                    title="Delete item"
                    disabled={!!deletingId}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
