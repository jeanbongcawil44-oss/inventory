import { useState, useMemo, useCallback, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Plus } from "lucide-react";

import { InventoryItem, SortConfig, SortField } from "@/types/inventory";
import { useInventory } from "@/context/InventoryContext";

import TopNav from "@/components/inventory/TopNav";
import StatsStrip from "@/components/inventory/StatsStrip";
import LowStockBanner from "@/components/inventory/LowStockBanner";
import FilterToolbar from "@/components/inventory/FilterToolbar";
import InventoryTable from "@/components/inventory/InventoryTable";
import ItemModal from "@/components/inventory/ItemModal";
import DeleteConfirm from "@/components/inventory/DeleteConfirm";
import EmptyState from "@/components/inventory/EmptyState";
import CategoryManager from "@/components/inventory/CategoryManager";

export default function InventoryDashboard() {
  const { items, categories, addItem, updateItem, deleteItem } = useInventory();
  const [searchQuery, setSearchQuery] = useState("");
  const [debouncedSearch, setDebouncedSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("");
  const [statusFilter, setStatusFilter] = useState("");
  const [sortConfig, setSortConfig] = useState<SortConfig>({ field: "name", direction: "asc" });
  const [bannerDismissed, setBannerDismissed] = useState(false);

  // Modal state
  const [modalOpen, setModalOpen] = useState(false);
  const [editItem, setEditItem] = useState<InventoryItem | null>(null);

  // Delete confirm state
  const [deleteTarget, setDeleteTarget] = useState<InventoryItem | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Category manager state
  const [categoryManagerOpen, setCategoryManagerOpen] = useState(false);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedSearch(searchQuery), 200);
    return () => clearTimeout(t);
  }, [searchQuery]);

  // Reset banner dismiss when new low-stock items appear
  useEffect(() => {
    const hasAlerts = items.some((i) => i.status === "low" || i.status === "out-of-stock");
    if (hasAlerts) setBannerDismissed(false);
  }, [items]);

  const filteredAndSorted = useMemo(() => {
    let result = [...items];

    if (debouncedSearch) {
      const q = debouncedSearch.toLowerCase();
      result = result.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.sku.toLowerCase().includes(q)
      );
    }

    if (categoryFilter) {
      result = result.filter((i) => i.category === categoryFilter);
    }

    if (statusFilter) {
      result = result.filter((i) => i.status === statusFilter);
    }

    result.sort((a, b) => {
      const dir = sortConfig.direction === "asc" ? 1 : -1;
      const aVal = a[sortConfig.field];
      const bVal = b[sortConfig.field];
      if (typeof aVal === "string" && typeof bVal === "string") {
        return aVal.localeCompare(bVal) * dir;
      }
      return ((aVal as number) - (bVal as number)) * dir;
    });

    return result;
  }, [items, debouncedSearch, categoryFilter, statusFilter, sortConfig]);

  const hasAlerts = items.some((i) => i.status === "low" || i.status === "out-of-stock");
  const showBanner = hasAlerts && !bannerDismissed;
  const hasFilters = !!(debouncedSearch || categoryFilter || statusFilter);

  const handleSort = useCallback(
    (field: SortField) => {
      setSortConfig((prev) =>
        prev.field === field
          ? { field, direction: prev.direction === "asc" ? "desc" : "asc" }
          : { field, direction: "asc" }
      );
    },
    []
  );

  const handleOpenAdd = () => {
    setEditItem(null);
    setModalOpen(true);
  };

  const handleOpenEdit = (item: InventoryItem) => {
    setEditItem(item);
    setModalOpen(true);
  };

  const handleSave = (item: InventoryItem) => {
    const exists = items.find((i) => i.id === item.id);
    if (exists) {
      updateItem(item);
    } else {
      const { id: _id, status: _status, ...rest } = item;
      addItem(rest);
    }
    setModalOpen(false);
    setEditItem(null);
  };

  const handleDeleteRequest = (id: string) => {
    const item = items.find((i) => i.id === id);
    if (item) setDeleteTarget(item);
  };

  const handleDeleteConfirm = () => {
    if (!deleteTarget) return;
    setDeletingId(deleteTarget.id);
    setTimeout(() => {
      deleteItem(deleteTarget.id);
      setDeletingId(null);
      setDeleteTarget(null);
    }, 300);
  };

  const handleClearFilters = () => {
    setSearchQuery("");
    setCategoryFilter("");
    setStatusFilter("");
  };

  return (
    <div
      className="min-h-screen"
      style={{
        background: "#0F1117",
        fontFamily: "Space Grotesk, sans-serif",
        backgroundImage:
          "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E\")",
      }}
    >
      <TopNav searchQuery={searchQuery} onSearchChange={setSearchQuery} />

      <main className="max-w-[1400px] mx-auto px-6 py-6 space-y-5">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <h1
              className="text-2xl font-bold text-[#E8EAF0]"
              style={{ fontFamily: "Syne, sans-serif" }}
            >
              Inventory
            </h1>
            <p className="text-sm text-[#7B8099] mt-0.5">Manage stock, pricing, and suppliers</p>
          </div>
          <button
            onClick={handleOpenAdd}
            className="flex items-center gap-2 px-4 py-2.5 rounded-lg text-sm font-semibold text-[#0F1117] transition-all hover:opacity-90 active:scale-[0.97]"
            style={{ background: "#00C9A7" }}
          >
            <Plus className="w-4 h-4" />
            Add Item
          </button>
        </div>

        {/* Stats */}
        <StatsStrip items={items} />

        {/* Low stock banner */}
        <AnimatePresence>
          {showBanner && (
            <motion.div
              initial={{ opacity: 0, y: -8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, height: 0, marginTop: 0 }}
              transition={{ duration: 0.25 }}
            >
              <LowStockBanner items={items} onDismiss={() => setBannerDismissed(true)} />
            </motion.div>
          )}
        </AnimatePresence>

        {/* Filter toolbar */}
        <FilterToolbar
          categoryFilter={categoryFilter}
          statusFilter={statusFilter}
          onCategoryChange={setCategoryFilter}
          onStatusChange={setStatusFilter}
          onManageCategories={() => setCategoryManagerOpen(true)}
          categories={categories}
          itemCount={filteredAndSorted.length}
          totalCount={items.length}
        />

        {/* Table / empty state */}
        {filteredAndSorted.length === 0 ? (
          <EmptyState
            hasFilters={hasFilters}
            onAddItem={handleOpenAdd}
            onClearFilters={handleClearFilters}
          />
        ) : (
          <InventoryTable
            items={filteredAndSorted}
            sortConfig={sortConfig}
            onSort={handleSort}
            onEdit={handleOpenEdit}
            onDelete={handleDeleteRequest}
            deletingId={deletingId}
          />
        )}
      </main>

      {/* Add / Edit modal */}
      <ItemModal
        open={modalOpen}
        editItem={editItem}
        onClose={() => {
          setModalOpen(false);
          setEditItem(null);
        }}
        onSave={handleSave}
        existingCategories={categories}
      />

      {/* Delete confirm */}
      <DeleteConfirm
        open={!!deleteTarget}
        itemName={deleteTarget?.name ?? ""}
        onConfirm={handleDeleteConfirm}
        onCancel={() => setDeleteTarget(null)}
      />

      {/* Category manager */}
      <CategoryManager
        open={categoryManagerOpen}
        onClose={() => setCategoryManagerOpen(false)}
      />
    </div>
  );
}
