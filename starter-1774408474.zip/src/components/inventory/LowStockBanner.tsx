import { AlertTriangle, X } from "lucide-react";
import { InventoryItem } from "@/types/inventory";

interface LowStockBannerProps {
  items: InventoryItem[];
  onDismiss: () => void;
}

export default function LowStockBanner({ items, onDismiss }: LowStockBannerProps) {
  const lowItems = items.filter((i) => i.status === "low");
  const outItems = items.filter((i) => i.status === "out-of-stock");

  return (
    <div className="flex items-center gap-3 px-4 py-3 rounded-xl border border-[#F5A623]/30 bg-[#F5A623]/10 text-sm" style={{ fontFamily: "Space Grotesk, sans-serif" }}>
      <AlertTriangle className="w-4 h-4 text-[#F5A623] shrink-0" />
      <div className="flex-1 text-[#E8EAF0]">
        <span className="font-semibold text-[#F5A623]">Stock Alert — </span>
        {outItems.length > 0 && (
          <span>
            <span className="text-[#E05C5C] font-medium">{outItems.length} item{outItems.length > 1 ? "s" : ""} out of stock</span>
            {lowItems.length > 0 ? " · " : ""}
          </span>
        )}
        {lowItems.length > 0 && (
          <span>
            <span className="text-[#F5A623] font-medium">{lowItems.length} item{lowItems.length > 1 ? "s" : ""} running low</span>
          </span>
        )}
        <span className="text-[#7B8099]"> — Review and reorder soon.</span>
      </div>
      <button
        onClick={onDismiss}
        className="ml-auto p-1 rounded hover:bg-[#F5A623]/20 text-[#7B8099] hover:text-[#E8EAF0] transition-colors"
      >
        <X className="w-4 h-4" />
      </button>
    </div>
  );
}
