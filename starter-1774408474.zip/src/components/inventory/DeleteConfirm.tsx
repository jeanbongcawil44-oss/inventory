import { AlertTriangle, Trash2 } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface DeleteConfirmProps {
  open: boolean;
  itemName: string;
  onConfirm: () => void;
  onCancel: () => void;
}

export default function DeleteConfirm({ open, itemName, onConfirm, onCancel }: DeleteConfirmProps) {
  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.15 }}
            className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
            onClick={onCancel}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            transition={{ duration: 0.15 }}
            className="fixed z-50 left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-sm rounded-xl border border-[#2A2D3A] p-6"
            style={{ background: "#1A1D27", fontFamily: "Space Grotesk, sans-serif" }}
          >
            <div className="flex items-start gap-4 mb-5">
              <div className="w-10 h-10 rounded-lg bg-[#E05C5C]/15 flex items-center justify-center shrink-0">
                <AlertTriangle className="w-5 h-5 text-[#E05C5C]" />
              </div>
              <div>
                <h3
                  className="text-base font-bold text-[#E8EAF0] mb-1"
                  style={{ fontFamily: "Syne, sans-serif" }}
                >
                  Delete Item
                </h3>
                <p className="text-sm text-[#7B8099]">
                  Are you sure you want to delete{" "}
                  <span className="text-[#E8EAF0] font-medium">"{itemName}"</span>? This action
                  cannot be undone.
                </p>
              </div>
            </div>

            <div className="flex gap-3">
              <button
                onClick={onCancel}
                className="flex-1 py-2.5 rounded-lg border border-[#2A2D3A] text-sm font-medium text-[#7B8099] hover:text-[#E8EAF0] hover:border-[#7B8099] transition-colors"
              >
                Cancel
              </button>
              <button
                onClick={onConfirm}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg bg-[#E05C5C]/20 border border-[#E05C5C]/30 text-sm font-semibold text-[#E05C5C] hover:bg-[#E05C5C]/30 transition-colors"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Delete
              </button>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
