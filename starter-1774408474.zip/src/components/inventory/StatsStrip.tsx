import { useEffect, useRef, useState } from "react";
import { Package, AlertTriangle, Tag, DollarSign } from "lucide-react";
import { InventoryItem } from "@/types/inventory";

interface StatsStripProps {
  items: InventoryItem[];
}

function useCountUp(target: number, duration = 1200) {
  const [value, setValue] = useState(0);
  const frameRef = useRef<number>(0);
  const startRef = useRef<number | null>(null);

  useEffect(() => {
    startRef.current = null;
    const animate = (ts: number) => {
      if (!startRef.current) startRef.current = ts;
      const progress = Math.min((ts - startRef.current) / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(eased * target));
      if (progress < 1) frameRef.current = requestAnimationFrame(animate);
    };
    frameRef.current = requestAnimationFrame(animate);
    return () => cancelAnimationFrame(frameRef.current);
  }, [target, duration]);

  return value;
}

function StatCard({
  label,
  value,
  displayValue,
  icon: Icon,
  accent,
  sub,
}: {
  label: string;
  value: number;
  displayValue?: string;
  icon: React.ElementType;
  accent: string;
  sub?: string;
}) {
  const animated = useCountUp(value);

  return (
    <div
      className="relative flex-1 min-w-0 rounded-xl border border-[#2A2D3A] p-5 overflow-hidden"
      style={{ background: "linear-gradient(135deg, #1A1D27 0%, #1e2132 100%)" }}
    >
      {/* Shimmer gradient */}
      <div
        className="absolute inset-0 opacity-30 pointer-events-none"
        style={{
          background: `radial-gradient(ellipse at 80% 20%, ${accent}18 0%, transparent 60%)`,
        }}
      />
      <div className="relative z-10">
        <div className="flex items-start justify-between mb-3">
          <div
            className="w-9 h-9 rounded-lg flex items-center justify-center"
            style={{ background: `${accent}20` }}
          >
            <Icon className="w-4 h-4" style={{ color: accent }} />
          </div>
        </div>
        <div
          className="text-3xl font-bold text-[#E8EAF0] mb-1 tabular-nums"
          style={{ fontFamily: "Syne, sans-serif" }}
        >
          {displayValue
            ? displayValue.replace(/\d+/, String(animated))
            : animated}
        </div>
        <div className="text-sm text-[#7B8099]" style={{ fontFamily: "Space Grotesk, sans-serif" }}>
          {label}
        </div>
        {sub && (
          <div className="mt-1 text-xs" style={{ color: accent, fontFamily: "Space Grotesk, sans-serif" }}>
            {sub}
          </div>
        )}
      </div>
    </div>
  );
}

export default function StatsStrip({ items }: StatsStripProps) {
  const totalItems = items.length;
  const lowStockCount = items.filter((i) => i.status === "low" || i.status === "out-of-stock").length;
  const categories = new Set(items.map((i) => i.category)).size;
  const totalValue = items.reduce((acc, i) => acc + i.quantity * i.unitPrice, 0);
  const totalValueInt = Math.round(totalValue);

  return (
    <div className="flex gap-4">
      <StatCard
        label="Total Items"
        value={totalItems}
        icon={Package}
        accent="#00C9A7"
      />
      <StatCard
        label="Alerts (Low / Out)"
        value={lowStockCount}
        icon={AlertTriangle}
        accent="#F5A623"
        sub={lowStockCount > 0 ? `${lowStockCount} need attention` : "All levels healthy"}
      />
      <StatCard
        label="Categories"
        value={categories}
        icon={Tag}
        accent="#818cf8"
      />
      <StatCard
        label="Inventory Value"
        value={totalValueInt}
        displayValue={`$${totalValueInt.toLocaleString()}`}
        icon={DollarSign}
        accent="#00C9A7"
        sub="Across all SKUs"
      />
    </div>
  );
}
