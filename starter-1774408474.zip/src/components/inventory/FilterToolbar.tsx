import { ChevronDown, Settings2 } from "lucide-react";

interface FilterToolbarProps {
  categoryFilter: string;
  statusFilter: string;
  onCategoryChange: (v: string) => void;
  onStatusChange: (v: string) => void;
  onManageCategories: () => void;
  categories: string[];
  itemCount: number;
  totalCount: number;
}

const SELECT_STYLE =
  "appearance-none pl-3 pr-8 py-2 text-sm bg-[#0F1117] border border-[#2A2D3A] rounded-lg text-[#E8EAF0] focus:outline-none focus:border-[#00C9A7]/60 cursor-pointer transition-colors hover:border-[#7B8099]/50";

export default function FilterToolbar({
  categoryFilter,
  statusFilter,
  onCategoryChange,
  onStatusChange,
  onManageCategories,
  categories,
  itemCount,
  totalCount,
}: FilterToolbarProps) {
  return (
    <div
      className="flex items-center gap-3 flex-wrap"
      style={{ fontFamily: "Space Grotesk, sans-serif" }}
    >
      <span className="text-sm text-[#7B8099]">
        Showing{" "}
        <span className="text-[#E8EAF0] font-medium">{itemCount}</span>
        {" / "}
        <span className="text-[#7B8099]">{totalCount}</span>
        {" items"}
      </span>

      <div className="flex-1" />

      {/* Category filter */}
      <div className="relative">
        <select
          value={categoryFilter}
          onChange={(e) => onCategoryChange(e.target.value)}
          className={SELECT_STYLE}
        >
          <option value="">All Categories</option>
          {categories.map((c) => (
            <option key={c} value={c}>
              {c}
            </option>
          ))}
        </select>
        <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#7B8099] pointer-events-none" />
      </div>

      {/* Manage categories button */}
      <button
        onClick={onManageCategories}
        title="Manage categories"
        className="flex items-center gap-1.5 px-3 py-2 text-sm text-[#7B8099] border border-[#2A2D3A] rounded-lg hover:text-[#00C9A7] hover:border-[#00C9A7]/40 hover:bg-[#00C9A7]/5 transition-all"
      >
        <Settings2 className="w-3.5 h-3.5" />
        <span className="hidden sm:inline">Categories</span>
      </button>

      {/* Status filter */}
      <div className="relative">
        <select
          value={statusFilter}
          onChange={(e) => onStatusChange(e.target.value)}
          className={SELECT_STYLE}
        >
          <option value="">All Status</option>
          <option value="in-stock">In Stock</option>
          <option value="low">Low Stock</option>
          <option value="out-of-stock">Out of Stock</option>
        </select>
        <ChevronDown className="absolute right-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-[#7B8099] pointer-events-none" />
      </div>
    </div>
  );
}
