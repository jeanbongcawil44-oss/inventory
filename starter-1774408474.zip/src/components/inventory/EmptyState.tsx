import { Package2 } from "lucide-react";

interface EmptyStateProps {
  hasFilters: boolean;
  onAddItem: () => void;
  onClearFilters: () => void;
}

export default function EmptyState({ hasFilters, onAddItem, onClearFilters }: EmptyStateProps) {
  return (
    <div
      className="flex flex-col items-center justify-center py-20 rounded-xl border border-[#2A2D3A] text-center"
      style={{ background: "#1A1D27", fontFamily: "Space Grotesk, sans-serif" }}
    >
      <div className="w-16 h-16 rounded-2xl bg-[#00C9A7]/10 border border-[#00C9A7]/20 flex items-center justify-center mb-5">
        <Package2 className="w-8 h-8 text-[#00C9A7]/60" />
      </div>
      <h3
        className="text-lg font-bold text-[#E8EAF0] mb-2"
        style={{ fontFamily: "Syne, sans-serif" }}
      >
        {hasFilters ? "No items match your filters" : "No inventory items yet"}
      </h3>
      <p className="text-sm text-[#7B8099] max-w-xs mb-6">
        {hasFilters
          ? "Try adjusting your search or filter criteria to find what you're looking for."
          : "Get started by adding your first inventory item. Track stock, prices, and suppliers all in one place."}
      </p>
      {hasFilters ? (
        <button
          onClick={onClearFilters}
          className="px-5 py-2.5 rounded-lg border border-[#2A2D3A] text-sm font-medium text-[#7B8099] hover:text-[#E8EAF0] hover:border-[#7B8099] transition-colors"
        >
          Clear Filters
        </button>
      ) : (
        <button
          onClick={onAddItem}
          className="px-5 py-2.5 rounded-lg text-sm font-semibold text-[#0F1117] transition-all hover:opacity-90"
          style={{ background: "#00C9A7" }}
        >
          + Add First Item
        </button>
      )}
    </div>
  );
}
