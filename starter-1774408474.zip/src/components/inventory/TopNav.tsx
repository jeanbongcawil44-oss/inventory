import { Bell, Search, LogOut } from "lucide-react";
import { useAuth } from "@/context/AuthContext";

interface TopNavProps {
  searchQuery: string;
  onSearchChange: (value: string) => void;
}

export default function TopNav({ searchQuery, onSearchChange }: TopNavProps) {
  const { user, logout } = useAuth();

  const initials = user
    ? user.name
        .split(" ")
        .map((w) => w[0]?.toUpperCase())
        .slice(0, 2)
        .join("")
    : "U";

  return (
    <header className="sticky top-0 z-50 h-16 flex items-center justify-between px-6 border-b border-[#2A2D3A] bg-[#0F1117]/95 backdrop-blur-sm">
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-[#00C9A7] flex items-center justify-center">
          <svg width="18" height="18" viewBox="0 0 18 18" fill="none">
            <rect x="2" y="2" width="6" height="6" rx="1" fill="#0F1117" />
            <rect x="10" y="2" width="6" height="6" rx="1" fill="#0F1117" />
            <rect x="2" y="10" width="6" height="6" rx="1" fill="#0F1117" />
            <rect x="10" y="10" width="6" height="6" rx="1" fill="#0F1117" opacity="0.4" />
          </svg>
        </div>
        <span className="font-bold text-[#E8EAF0] text-lg tracking-tight" style={{ fontFamily: "Syne, sans-serif" }}>
          StockPilot
        </span>
      </div>

      {/* Search */}
      <div className="flex-1 max-w-md mx-8">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#7B8099]" />
          <input
            type="text"
            placeholder="Search by name or SKU…"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm bg-[#1A1D27] border border-[#2A2D3A] rounded-lg text-[#E8EAF0] placeholder-[#7B8099] focus:outline-none focus:border-[#00C9A7]/60 focus:ring-1 focus:ring-[#00C9A7]/30 transition-all"
            style={{ fontFamily: "Space Grotesk, sans-serif" }}
          />
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-3">
        <button className="relative w-9 h-9 rounded-lg flex items-center justify-center hover:bg-[#1A1D27] text-[#7B8099] hover:text-[#E8EAF0] transition-colors">
          <Bell className="w-4 h-4" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[#F5A623] rounded-full"></span>
        </button>

        {/* User avatar + name */}
        <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg">
          <div
            className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold text-[#0F1117]"
            style={{ background: "linear-gradient(135deg, #00C9A7, #0097a7)" }}
          >
            {initials}
          </div>
          <span className="text-sm text-[#E8EAF0] font-medium hidden sm:block" style={{ fontFamily: "Space Grotesk, sans-serif" }}>
            {user?.name ?? "User"}
          </span>
        </div>

        {/* Logout */}
        <button
          onClick={logout}
          title="Sign out"
          className="w-9 h-9 rounded-lg flex items-center justify-center hover:bg-[#E05C5C]/10 text-[#7B8099] hover:text-[#E05C5C] transition-colors"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </header>
  );
}

