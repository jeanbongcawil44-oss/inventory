import { useEffect, useRef } from "react";
import { X, PackageOpen } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { InventoryItem } from "@/types/inventory";
import { computeStatus } from "@/data/mockInventory";

const schema = z.object({
  name: z.string().min(1, "Name is required"),
  sku: z.string().min(1, "SKU is required"),
  category: z.string().min(1, "Category is required"),
  quantity: z.coerce.number().int().min(0, "Quantity must be ≥ 0"),
  unitPrice: z.coerce.number().min(0, "Price must be ≥ 0"),
  supplier: z.string().min(1, "Supplier is required"),
});

type FormData = z.infer<typeof schema>;

interface ItemModalProps {
  open: boolean;
  editItem: InventoryItem | null;
  onClose: () => void;
  onSave: (item: InventoryItem) => void;
  existingCategories: string[];
}

const FIELD_STYLE =
  "w-full px-3 py-2.5 text-sm bg-[#0F1117] border border-[#2A2D3A] rounded-lg text-[#E8EAF0] placeholder-[#7B8099] focus:outline-none focus:border-[#00C9A7]/60 focus:ring-1 focus:ring-[#00C9A7]/30 transition-all";

export default function ItemModal({
  open,
  editItem,
  onClose,
  onSave,
  existingCategories,
}: ItemModalProps) {
  const isEdit = !!editItem;
  const overlayRef = useRef<HTMLDivElement>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<FormData>({ resolver: zodResolver(schema) });

  useEffect(() => {
    if (open) {
      if (editItem) {
        reset({
          name: editItem.name,
          sku: editItem.sku,
          category: editItem.category,
          quantity: editItem.quantity,
          unitPrice: editItem.unitPrice,
          supplier: editItem.supplier,
        });
      } else {
        reset({ name: "", sku: "", category: "", quantity: 0, unitPrice: 0, supplier: "" });
      }
    }
  }, [open, editItem, reset]);

  const onSubmit = (data: FormData) => {
    const item: InventoryItem = {
      id: editItem?.id ?? String(Date.now()),
      name: data.name,
      sku: data.sku,
      category: data.category,
      quantity: data.quantity,
      unitPrice: data.unitPrice,
      supplier: data.supplier,
      status: computeStatus(data.quantity),
    };
    onSave(item);
  };

  // Close on overlay click
  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose();
  };

  return (
    <AnimatePresence>
      {open && (
        <>
          {/* Backdrop */}
          <motion.div
            ref={overlayRef}
            onClick={handleOverlayClick}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
          />

          {/* Panel */}
          <motion.div
            initial={{ x: "100%" }}
            animate={{ x: 0 }}
            exit={{ x: "100%" }}
            transition={{ type: "spring", damping: 28, stiffness: 280 }}
            className="fixed right-0 top-0 z-50 h-full w-full max-w-md flex flex-col border-l border-[#2A2D3A]"
            style={{ background: "#1A1D27", fontFamily: "Space Grotesk, sans-serif" }}
          >
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-5 border-b border-[#2A2D3A]">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-lg bg-[#00C9A7]/15 flex items-center justify-center">
                  <PackageOpen className="w-4 h-4 text-[#00C9A7]" />
                </div>
                <div>
                  <h2
                    className="text-base font-bold text-[#E8EAF0]"
                    style={{ fontFamily: "Syne, sans-serif" }}
                  >
                    {isEdit ? "Edit Item" : "Add New Item"}
                  </h2>
                  <p className="text-xs text-[#7B8099]">
                    {isEdit ? `Editing: ${editItem?.sku}` : "Create a new inventory entry"}
                  </p>
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-1.5 rounded-lg text-[#7B8099] hover:text-[#E8EAF0] hover:bg-[#ffffff]/5 transition-colors"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit(onSubmit)} className="flex flex-col flex-1 overflow-y-auto">
              <div className="flex-1 px-6 py-5 space-y-5">
                {/* Name */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Item Name
                  </label>
                  <input
                    {...register("name")}
                    placeholder="e.g. Wireless Keyboard"
                    className={FIELD_STYLE}
                  />
                  {errors.name && (
                    <p className="mt-1 text-xs text-[#E05C5C]">{errors.name.message}</p>
                  )}
                </div>

                {/* SKU */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    SKU
                  </label>
                  <input
                    {...register("sku")}
                    placeholder="e.g. WK-1001"
                    className={`${FIELD_STYLE} font-mono`}
                  />
                  {errors.sku && (
                    <p className="mt-1 text-xs text-[#E05C5C]">{errors.sku.message}</p>
                  )}
                </div>

                {/* Category */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Category
                  </label>
                  <input
                    {...register("category")}
                    list="category-list"
                    placeholder="e.g. Electronics"
                    className={FIELD_STYLE}
                  />
                  <datalist id="category-list">
                    {existingCategories.map((c) => (
                      <option key={c} value={c} />
                    ))}
                  </datalist>
                  {errors.category && (
                    <p className="mt-1 text-xs text-[#E05C5C]">{errors.category.message}</p>
                  )}
                </div>

                {/* Quantity + Price row */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                      Quantity
                    </label>
                    <input
                      {...register("quantity")}
                      type="number"
                      min="0"
                      className={FIELD_STYLE}
                    />
                    {errors.quantity && (
                      <p className="mt-1 text-xs text-[#E05C5C]">{errors.quantity.message}</p>
                    )}
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                      Unit Price ($)
                    </label>
                    <input
                      {...register("unitPrice")}
                      type="number"
                      min="0"
                      step="0.01"
                      className={FIELD_STYLE}
                    />
                    {errors.unitPrice && (
                      <p className="mt-1 text-xs text-[#E05C5C]">{errors.unitPrice.message}</p>
                    )}
                  </div>
                </div>

                {/* Supplier */}
                <div>
                  <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-1.5">
                    Supplier
                  </label>
                  <input
                    {...register("supplier")}
                    placeholder="e.g. TechSupply Co."
                    className={FIELD_STYLE}
                  />
                  {errors.supplier && (
                    <p className="mt-1 text-xs text-[#E05C5C]">{errors.supplier.message}</p>
                  )}
                </div>
              </div>

              {/* Footer */}
              <div className="px-6 py-5 border-t border-[#2A2D3A] flex gap-3">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-2.5 rounded-lg border border-[#2A2D3A] text-sm font-medium text-[#7B8099] hover:text-[#E8EAF0] hover:border-[#7B8099] transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 rounded-lg text-sm font-semibold text-[#0F1117] transition-all hover:opacity-90 active:scale-[0.98]"
                  style={{ background: "#00C9A7" }}
                >
                  {isEdit ? "Save Changes" : "Add Item"}
                </button>
              </div>
            </form>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
