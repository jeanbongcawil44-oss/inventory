import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { X, Plus, Pencil, Trash2, Tag, Check, AlertCircle } from "lucide-react";
import { useInventory } from "@/context/InventoryContext";

interface CategoryManagerProps {
  open: boolean;
  onClose: () => void;
}

export default function CategoryManager({ open, onClose }: CategoryManagerProps) {
  const { categories, addCategory, deleteCategory, renameCategory, items } = useInventory();
  const [newCat, setNewCat] = useState("");
  const [newCatError, setNewCatError] = useState("");
  const [editingCat, setEditingCat] = useState<string | null>(null);
  const [editValue, setEditValue] = useState("");
  const [editError, setEditError] = useState("");
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const getItemCount = (cat: string) => items.filter((i) => i.category === cat).length;

  const handleAdd = () => {
    if (!newCat.trim()) {
      setNewCatError("Category name is required");
      return;
    }
    const ok = addCategory(newCat);
    if (!ok) {
      setNewCatError("Category already exists");
      return;
    }
    setNewCat("");
    setNewCatError("");
  };

  const handleStartEdit = (cat: string) => {
    setEditingCat(cat);
    setEditValue(cat);
    setEditError("");
    setDeleteConfirm(null);
  };

  const handleSaveEdit = () => {
    if (!editValue.trim()) {
      setEditError("Name cannot be empty");
      return;
    }
    const ok = renameCategory(editingCat!, editValue);
    if (!ok) {
      setEditError("Name already in use");
      return;
    }
    setEditingCat(null);
    setEditError("");
  };

  const handleDelete = (cat: string) => {
    deleteCategory(cat);
    setDeleteConfirm(null);
  };

  if (!open) return null;

  return (
    <AnimatePresence>
      {open && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm"
            onClick={onClose}
          />
          <motion.div
            initial={{ opacity: 0, scale: 0.95, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20 }}
            transition={{ type: "spring", damping: 28, stiffness: 300 }}
            className="fixed inset-0 z-50 flex items-center justify-center px-4 pointer-events-none"
          >
            <div
              className="w-full max-w-md rounded-2xl border border-[#2A2D3A] flex flex-col pointer-events-auto max-h-[90vh]"
              style={{ background: "#1A1D27", fontFamily: "Space Grotesk, sans-serif" }}
              onClick={(e) => e.stopPropagation()}
            >
              {/* Header */}
              <div className="flex items-center justify-between px-6 py-5 border-b border-[#2A2D3A]">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#00C9A7]/15 flex items-center justify-center">
                    <Tag className="w-4 h-4 text-[#00C9A7]" />
                  </div>
                  <div>
                    <h2
                      className="text-base font-bold text-[#E8EAF0]"
                      style={{ fontFamily: "Syne, sans-serif" }}
                    >
                      Manage Categories
                    </h2>
                    <p className="text-xs text-[#7B8099]">
                      {categories.length} categories
                    </p>
                  </div>
                </div>
                <button
                  onClick={onClose}
                  className="p-1.5 rounded-lg text-[#7B8099] hover:text-[#E8EAF0] hover:bg-white/5 transition-colors"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>

              {/* Add new */}
              <div className="px-6 py-4 border-b border-[#2A2D3A]">
                <label className="block text-xs font-semibold text-[#7B8099] uppercase tracking-wider mb-2">
                  Add New Category
                </label>
                <div className="flex gap-2">
                  <input
                    value={newCat}
                    onChange={(e) => {
                      setNewCat(e.target.value);
                      setNewCatError("");
                    }}
                    onKeyDown={(e) => e.key === "Enter" && handleAdd()}
                    placeholder="e.g. Tools & Hardware"
                    className="flex-1 px-3 py-2.5 text-sm bg-[#0F1117] border border-[#2A2D3A] rounded-lg text-[#E8EAF0] placeholder-[#7B8099] focus:outline-none focus:border-[#00C9A7]/60 focus:ring-1 focus:ring-[#00C9A7]/30 transition-all"
                  />
                  <button
                    onClick={handleAdd}
                    className="flex items-center gap-1.5 px-4 py-2.5 rounded-lg text-sm font-semibold text-[#0F1117] transition-all hover:opacity-90 active:scale-[0.97]"
                    style={{ background: "#00C9A7" }}
                  >
                    <Plus className="w-3.5 h-3.5" />
                    Add
                  </button>
                </div>
                {newCatError && (
                  <p className="mt-1.5 text-xs text-[#E05C5C] flex items-center gap-1">
                    <AlertCircle className="w-3 h-3" />
                    {newCatError}
                  </p>
                )}
              </div>

              {/* Category list */}
              <div className="flex-1 overflow-y-auto px-6 py-4 space-y-2">
                {categories.length === 0 && (
                  <p className="text-sm text-[#7B8099] text-center py-8">
                    No categories yet. Add one above.
                  </p>
                )}
                <AnimatePresence mode="popLayout">
                  {categories.map((cat) => (
                    <motion.div
                      key={cat}
                      layout
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, x: -20, height: 0, marginBottom: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      {editingCat === cat ? (
                        <div className="rounded-xl border border-[#00C9A7]/40 bg-[#00C9A7]/5 p-3">
                          <div className="flex gap-2">
                            <input
                              autoFocus
                              value={editValue}
                              onChange={(e) => {
                                setEditValue(e.target.value);
                                setEditError("");
                              }}
                              onKeyDown={(e) => {
                                if (e.key === "Enter") handleSaveEdit();
                                if (e.key === "Escape") setEditingCat(null);
                              }}
                              className="flex-1 px-3 py-2 text-sm bg-[#0F1117] border border-[#2A2D3A] rounded-lg text-[#E8EAF0] focus:outline-none focus:border-[#00C9A7]/60 focus:ring-1 focus:ring-[#00C9A7]/30 transition-all"
                            />
                            <button
                              onClick={handleSaveEdit}
                              className="p-2 rounded-lg bg-[#00C9A7]/20 text-[#00C9A7] hover:bg-[#00C9A7]/30 transition-colors"
                            >
                              <Check className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => setEditingCat(null)}
                              className="p-2 rounded-lg text-[#7B8099] hover:text-[#E8EAF0] hover:bg-white/5 transition-colors"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </div>
                          {editError && (
                            <p className="mt-1.5 text-xs text-[#E05C5C] flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" />
                              {editError}
                            </p>
                          )}
                        </div>
                      ) : deleteConfirm === cat ? (
                        <div className="rounded-xl border border-[#E05C5C]/40 bg-[#E05C5C]/5 p-3 flex items-center gap-3">
                          <p className="flex-1 text-sm text-[#E8EAF0]">
                            Delete{" "}
                            <span className="font-semibold text-[#E05C5C]">{cat}</span>?
                            {getItemCount(cat) > 0 && (
                              <span className="text-[#7B8099]">
                                {" "}({getItemCount(cat)} items affected)
                              </span>
                            )}
                          </p>
                          <button
                            onClick={() => handleDelete(cat)}
                            className="px-3 py-1.5 rounded-lg bg-[#E05C5C]/20 text-[#E05C5C] text-xs font-semibold hover:bg-[#E05C5C]/30 transition-colors"
                          >
                            Delete
                          </button>
                          <button
                            onClick={() => setDeleteConfirm(null)}
                            className="px-3 py-1.5 rounded-lg text-[#7B8099] text-xs font-medium hover:text-[#E8EAF0] transition-colors"
                          >
                            Cancel
                          </button>
                        </div>
                      ) : (
                        <div className="rounded-xl border border-[#2A2D3A] bg-[#0F1117]/50 px-4 py-3 flex items-center gap-3 group hover:border-[#2A2D3A]/80 transition-colors">
                          <div className="w-7 h-7 rounded-lg bg-[#00C9A7]/10 flex items-center justify-center flex-shrink-0">
                            <Tag className="w-3.5 h-3.5 text-[#00C9A7]" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-[#E8EAF0]">{cat}</p>
                            <p className="text-xs text-[#7B8099]">
                              {getItemCount(cat)} item{getItemCount(cat) !== 1 ? "s" : ""}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                            <button
                              onClick={() => handleStartEdit(cat)}
                              className="p-1.5 rounded-lg text-[#7B8099] hover:text-[#00C9A7] hover:bg-[#00C9A7]/10 transition-colors"
                            >
                              <Pencil className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                setDeleteConfirm(cat);
                                setEditingCat(null);
                              }}
                              className="p-1.5 rounded-lg text-[#7B8099] hover:text-[#E05C5C] hover:bg-[#E05C5C]/10 transition-colors"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                      )}
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>

              {/* Footer */}
              <div className="px-6 py-4 border-t border-[#2A2D3A]">
                <button
                  onClick={onClose}
                  className="w-full py-2.5 rounded-xl border border-[#2A2D3A] text-sm font-medium text-[#7B8099] hover:text-[#E8EAF0] hover:border-[#7B8099] transition-colors"
                >
                  Done
                </button>
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
