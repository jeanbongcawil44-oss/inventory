import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Sparkles, X } from "lucide-react";
import InventoryDashboard from "@/components/inventory/InventoryDashboard";
import LoginPage from "@/components/auth/LoginPage";
import { useAuth } from "@/context/AuthContext";

function WelcomeBanner({ name, isNew, onClose }: { name: string; isNew: boolean; onClose: () => void }) {
  useEffect(() => {
    const t = setTimeout(onClose, 5000);
    return () => clearTimeout(t);
  }, [onClose]);

  return (
    <motion.div
      initial={{ opacity: 0, y: -60 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -60 }}
      transition={{ type: "spring", stiffness: 300, damping: 28 }}
      className="fixed top-4 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3 px-5 py-3 rounded-2xl border shadow-2xl"
      style={{
        background: "linear-gradient(135deg, #1A1D27 0%, #1e2235 100%)",
        borderColor: "#00C9A7",
        boxShadow: "0 0 30px rgba(0,201,167,0.2)",
        fontFamily: "Space Grotesk, sans-serif",
      }}
    >
      <div
        className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: "rgba(0,201,167,0.15)" }}
      >
        <Sparkles className="w-4 h-4" style={{ color: "#00C9A7" }} />
      </div>
      <div>
        <p className="text-sm font-bold text-[#E8EAF0]">
          {isNew ? `Welcome, ${name}! 🎉` : `Welcome back, ${name}!`}
        </p>
        <p className="text-xs text-[#7B8099]">
          {isNew ? "Your account is ready. Start managing inventory!" : "Good to see you again."}
        </p>
      </div>
      <button
        onClick={onClose}
        className="ml-2 text-[#7B8099] hover:text-[#E8EAF0] transition-colors"
      >
        <X className="w-4 h-4" />
      </button>
    </motion.div>
  );
}

function Home() {
  const { isAuthenticated, user, isNewUser, clearNewUser } = useAuth();
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    if (isAuthenticated && user) {
      setShowWelcome(true);
    }
  }, [isAuthenticated, user]);

  const handleCloseWelcome = () => {
    setShowWelcome(false);
    clearNewUser();
  };

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  return (
    <>
      <AnimatePresence>
        {showWelcome && user && (
          <WelcomeBanner
            name={user.name}
            isNew={isNewUser}
            onClose={handleCloseWelcome}
          />
        )}
      </AnimatePresence>
      <InventoryDashboard />
    </>
  );
}

export default Home;

