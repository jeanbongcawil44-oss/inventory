import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { InventoryItem } from "@/types/inventory";
import { MOCK_ITEMS, computeStatus } from "@/data/mockInventory";

const ITEMS_KEY = "stockpilot_items";
const CATEGORIES_KEY = "stockpilot_categories";

const DEFAULT_CATEGORIES = [
  "Electronics",
  "Furniture",
  "Stationery",
  "Accessories",
  "Packaging",
];

interface InventoryContextType {
  items: InventoryItem[];
  categories: string[];
  addItem: (item: Omit<InventoryItem, "id" | "status">) => void;
  updateItem: (item: InventoryItem) => void;
  deleteItem: (id: string) => void;
  addCategory: (name: string) => boolean; // returns false if duplicate
  deleteCategory: (name: string) => void;
  renameCategory: (oldName: string, newName: string) => boolean;
}

const InventoryContext = createContext<InventoryContextType | null>(null);

export function InventoryProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<InventoryItem[]>(() => {
    try {
      const stored = localStorage.getItem(ITEMS_KEY);
      return stored ? JSON.parse(stored) : MOCK_ITEMS;
    } catch {
      return MOCK_ITEMS;
    }
  });

  const [categories, setCategories] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(CATEGORIES_KEY);
      return stored ? JSON.parse(stored) : DEFAULT_CATEGORIES;
    } catch {
      return DEFAULT_CATEGORIES;
    }
  });

  // Persist items
  useEffect(() => {
    localStorage.setItem(ITEMS_KEY, JSON.stringify(items));
  }, [items]);

  // Persist categories
  useEffect(() => {
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
  }, [categories]);

  const addItem = (data: Omit<InventoryItem, "id" | "status">) => {
    const newItem: InventoryItem = {
      ...data,
      id: String(Date.now()),
      status: computeStatus(data.quantity),
    };
    setItems((prev) => [newItem, ...prev]);
    // Auto-add category if new
    if (!categories.includes(data.category)) {
      setCategories((prev) => [...prev, data.category].sort());
    }
  };

  const updateItem = (item: InventoryItem) => {
    const updated = { ...item, status: computeStatus(item.quantity) };
    setItems((prev) => prev.map((i) => (i.id === item.id ? updated : i)));
    if (!categories.includes(item.category)) {
      setCategories((prev) => [...prev, item.category].sort());
    }
  };

  const deleteItem = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const addCategory = (name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return false;
    if (categories.some((c) => c.toLowerCase() === trimmed.toLowerCase())) return false;
    setCategories((prev) => [...prev, trimmed].sort());
    return true;
  };

  const deleteCategory = (name: string) => {
    setCategories((prev) => prev.filter((c) => c !== name));
    // Items keep their category but it won't appear in filter
  };

  const renameCategory = (oldName: string, newName: string) => {
    const trimmed = newName.trim();
    if (!trimmed) return false;
    if (categories.some((c) => c.toLowerCase() === trimmed.toLowerCase() && c !== oldName)) return false;
    setCategories((prev) => prev.map((c) => (c === oldName ? trimmed : c)).sort());
    setItems((prev) =>
      prev.map((i) => (i.category === oldName ? { ...i, category: trimmed } : i))
    );
    return true;
  };

  return (
    <InventoryContext.Provider
      value={{ items, categories, addItem, updateItem, deleteItem, addCategory, deleteCategory, renameCategory }}
    >
      {children}
    </InventoryContext.Provider>
  );
}

export function useInventory() {
  const ctx = useContext(InventoryContext);
  if (!ctx) throw new Error("useInventory must be used within InventoryProvider");
  return ctx;
}
