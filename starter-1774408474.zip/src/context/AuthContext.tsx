import { createContext, useContext, useState, ReactNode } from "react";
import { User, DEMO_ACCOUNTS, USERS_STORAGE_KEY } from "@/types/auth";

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => { success: boolean; error?: string };
  register: (name: string, email: string, password: string) => { success: boolean; error?: string };
  logout: () => void;
  isAuthenticated: boolean;
  isNewUser: boolean;
  clearNewUser: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

const AUTH_KEY = "stockpilot_auth";

type StoredUser = User & { password: string };

function loadUsers(): StoredUser[] {
  try {
    const stored = localStorage.getItem(USERS_STORAGE_KEY);
    if (stored) return JSON.parse(stored);
  } catch {}
  const defaults: StoredUser[] = DEMO_ACCOUNTS as StoredUser[];
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(defaults));
  return defaults;
}

function saveUsers(users: StoredUser[]) {
  localStorage.setItem(USERS_STORAGE_KEY, JSON.stringify(users));
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem(AUTH_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [isNewUser, setIsNewUser] = useState(false);

  const login = (email: string, password: string) => {
    const users = loadUsers();
    const account = users.find(
      (a) => a.email.toLowerCase() === email.toLowerCase() && a.password === password
    );
    if (!account) {
      return { success: false, error: "Invalid email or password" };
    }
    const { password: _pw, ...userWithoutPassword } = account;
    setUser(userWithoutPassword);
    setIsNewUser(false);
    localStorage.setItem(AUTH_KEY, JSON.stringify(userWithoutPassword));
    return { success: true };
  };

  const register = (name: string, email: string, password: string) => {
    const trimmedName = name.trim();
    const trimmedEmail = email.trim().toLowerCase();

    if (!trimmedName || !trimmedEmail || !password) {
      return { success: false, error: "All fields are required" };
    }
    if (password.length < 6) {
      return { success: false, error: "Password must be at least 6 characters" };
    }

    const users = loadUsers();
    if (users.some((u) => u.email.toLowerCase() === trimmedEmail)) {
      return { success: false, error: "An account with this email already exists" };
    }

    const initials = trimmedName
      .split(" ")
      .map((w) => w[0]?.toUpperCase() ?? "")
      .slice(0, 2)
      .join("");

    const newUser: StoredUser = {
      id: `u_${Date.now()}`,
      email: trimmedEmail,
      password,
      name: trimmedName,
      avatar: initials || trimmedName[0]?.toUpperCase() || "U",
      role: "viewer",
    };

    saveUsers([...users, newUser]);

    const { password: _pw, ...userWithoutPassword } = newUser;
    setUser(userWithoutPassword);
    setIsNewUser(true);
    localStorage.setItem(AUTH_KEY, JSON.stringify(userWithoutPassword));
    return { success: true };
  };

  const logout = () => {
    setUser(null);
    setIsNewUser(false);
    localStorage.removeItem(AUTH_KEY);
  };

  const clearNewUser = () => setIsNewUser(false);

  return (
    <AuthContext.Provider
      value={{ user, login, register, logout, isAuthenticated: !!user, isNewUser, clearNewUser }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
