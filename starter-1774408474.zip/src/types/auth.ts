export interface User {
  id: string;
  email: string;
  name: string;
  avatar: string;
  role: "admin" | "manager" | "viewer";
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
}

// Demo accounts
export const DEMO_ACCOUNTS: (User & { password: string })[] = [
  {
    id: "u1",
    email: "admin@stockpilot.io",
    password: "admin123",
    name: "Alex Admin",
    avatar: "AA",
    role: "admin",
  },
  {
    id: "u2",
    email: "manager@stockpilot.io",
    password: "manager123",
    name: "Morgan Manager",
    avatar: "MM",
    role: "manager",
  },
  {
    id: "u3",
    email: "viewer@stockpilot.io",
    password: "viewer123",
    name: "Val Viewer",
    avatar: "VV",
    role: "viewer",
  },
];

export const USERS_STORAGE_KEY = "stockpilot_users";
