export type ItemStatus = "in-stock" | "low" | "out-of-stock";

export interface InventoryItem {
  id: string;
  name: string;
  sku: string;
  category: string;
  quantity: number;
  unitPrice: number;
  supplier: string;
  status: ItemStatus;
}

export type SortField = "name" | "sku" | "category" | "quantity" | "unitPrice" | "status";
export type SortDirection = "asc" | "desc";

export interface SortConfig {
  field: SortField;
  direction: SortDirection;
}

export interface FilterConfig {
  category: string;
  status: string;
  search: string;
}
